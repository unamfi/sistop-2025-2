import javax.swing.*;

public class Pri {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(EmocionesApp::new);
    }
}